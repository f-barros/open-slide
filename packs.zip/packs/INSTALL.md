# Install comp-slide (local tarball test build)

This folder contains unpublished npm packages for local testing:

| File | Package | Role |
| --- | --- | --- |
| `comp-slide-cli-1.4.1.tgz` | `@comp-slide/cli` | Project scaffolder (`init`) |
| `comp-slide-core-1.17.1.tgz` | `@comp-slide/core` | Runtime, Vite plugin, `open-slide` CLI |

These packages are **not** on the public npm registry. Always install from the `.tgz` files in this folder.

## Requirements

- Node.js 18+
- npm, pnpm, or yarn

## Create a new deck project

Put both tarballs in the same directory (this folder is fine), then:

```bash
# Scaffold (skip auto-install so we can wire core from the local tarball)
npx --yes ./comp-slide-cli-1.4.1.tgz init my-deck --no-install

cd my-deck

# Install deps, using the local core package
npm install ../comp-slide-core-1.17.1.tgz

npm run dev
```

Open the URL printed by the dev server (usually `http://localhost:5173`).

### pnpm / yarn

```bash
npx --yes ./comp-slide-cli-1.4.1.tgz init my-deck --no-install
cd my-deck

# pnpm
pnpm add ../comp-slide-core-1.17.1.tgz
pnpm install
pnpm dev

# or yarn
yarn add ../comp-slide-core-1.17.1.tgz
yarn
yarn dev
```

## Existing project

If you already have a slide workspace:

```bash
npm install /absolute/or/relative/path/to/comp-slide-core-1.17.1.tgz
```

Then update imports (if any still say `@open-slide/core`) to:

```ts
import type { Page, SlideMeta } from '@comp-slide/core';
```

## What to expect

New projects use a modular layout:

```text
slides/<deck-id>/
├── index.tsx          # sole deck entry (page order)
├── slides/            # one file per page
├── components/        # shared chrome / theme
└── assets/
```

Starter deck: `slides/getting-started/`.

## Troubleshooting

**`npm install` fails resolving `@comp-slide/core`**  
The scaffolder writes a registry version range. That package is not published — install the local `comp-slide-core-*.tgz` as shown above (prefer `--no-install` on `init`).

**Wrong path to the tarball**  
Paths in `npm install ../comp-slide-core-1.17.1.tgz` are relative to the project folder. Adjust if your tarballs live elsewhere.

**Agent skills**  
After install, skills under `.agents/skills/` reference `@comp-slide/core`. Run `npm run sync:skills` if you refresh the core tarball later.

## Share checklist

Send colleagues this folder (or a zip) containing:

1. `comp-slide-cli-1.4.1.tgz`
2. `comp-slide-core-1.17.1.tgz`
3. this `INSTALL.md`
